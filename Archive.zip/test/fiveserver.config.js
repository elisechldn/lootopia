module.exports = {
  debugVSCode: true,
};
